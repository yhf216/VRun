import asyncio
import contextlib
import functools
import logging
import platform
import re
import subprocess
import uuid
from asyncio import IncompleteReadError
from collections import deque
from collections.abc import AsyncIterable
from typing import Any, Callable, Optional, Union, cast

from bytestruct import TruncatedDataError
from hyperframe.frame import (
    DataFrame,
    Frame,
    GoAwayFrame,
    HeadersFrame,
    RstStreamFrame,
    SettingsFrame,
    WindowUpdateFrame,
)
from pygments import formatters, highlight, lexers

from pymobiledevice3.exceptions import (
    ConnectionTerminatedError,
    NotConnectedError,
    ProtocolError,
    PyMobileDevice3Exception,
    RemoteXPCHandshakeTimeoutError,
    StreamClosedError,
)
from pymobiledevice3.pair_records import generate_host_id
from pymobiledevice3.remote.xpc_message import (
    XpcFlags,
    XpcInt64Type,
    XpcMessageType,
    XpcUInt64Type,
    XpcWrapper,
    create_xpc_wrapper,
    decode_xpc_object,
)
from pymobiledevice3.utils import start_ipython_shell

logger = logging.getLogger(__name__)


# Extracted by sniffing `remoted` traffic via Wireshark
DEFAULT_SETTINGS_MAX_CONCURRENT_STREAMS = 100
# Keep enough file-transfer data in flight to avoid frequent flow-control round trips.
DEFAULT_SETTINGS_INITIAL_WINDOW_SIZE = 16 * 1024 * 1024
DEFAULT_WIN_SIZE_INCR = DEFAULT_SETTINGS_INITIAL_WINDOW_SIZE - 65535
WINDOW_UPDATE_THRESHOLD = 1024 * 1024

FRAME_HEADER_SIZE = 9
HTTP2_MAGIC = b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n"

# HTTP/2 defaults for the peer's side of flow control, until its SETTINGS say otherwise.
DEFAULT_PEER_WINDOW_SIZE = 65535
MAX_OUTBOUND_FRAME_SIZE = 16384
# How long to wait for the peer to grant more outbound window before giving up on a transfer.
FILE_TRANSFER_WINDOW_TIMEOUT = 30

ROOT_CHANNEL = 1
REPLY_CHANNEL = 3

# Announce ourselves as a modern (non-legacy) RemoteXPC peer.
REMOTE_XPC_VERSION_FLAGS = 0x0100000000000006
MESSAGING_PROTOCOL_VERSION = 7

FIRST_REPLY_TIMEOUT = 3

_IS_DARWIN = platform.system() == "Darwin"

# ``remotectl dumpstate`` prints the host ``remoted``'s own identity first (see host_remoted_uuid).
_REMOTECTL_PATH = "/usr/libexec/remotectl"
_REMOTECTL_TIMEOUT = 10.0
_REMOTECTL_LOCAL_UUID_RE = re.compile(r"^Local device\n\s+UUID: (?P<uuid>[0-9A-Fa-f-]{36})$", re.MULTILINE)


@functools.cache
def default_handshake_uuid() -> uuid.UUID:
    """The UUID every RSD handshake from this host identifies itself with, unless told otherwise.

    The device's ``remoted`` applies two rules to incoming RSD connections (read from iOS 27.2's
    ``/usr/libexec/remoted``):

    * **Replacement, by source address.** An incoming connection whose source IP (port stripped)
      matches a peer it already has replaces that peer's connection ("canceling existing
      connection to replace it"), before any handshake is read. Every process on one host end of a
      link shares that address, so connections to the same tunnel replace one another whatever
      UUID they send.
    * **Re-attach, by handshake UUID** (``-[RSDRemoteDevice shouldReattachForHandshake:]``). Each
      handshake stores its ``UUID`` on the peer, and stores nothing when the key is missing. When
      the peer already has a stored UUID and a new handshake carries a different one ("Peer UUID
      changed across reconnect; reattaching so clients re-discover it"), the device re-attaches:
      every service listener it advertised, to the newcomer and to earlier connections alike, is
      closed and each port refuses connections.

    So all connections to a tunnel, across processes, must present one UUID: the deterministic host
    id pymobiledevice3 already pairs with. Leaving the key out would avoid the re-attach, but over
    the native tunnel such handshakes timed out, so it is always sent.

    It must not be the host ``remoted``'s on a tunnel of our own: from iOS 26.2, handshakes
    presenting remoted's UUID were seen to evict remoted's own connection, remoted redialed and
    reset ours, and after a few rounds remoted stopped redialing at all -- leaving
    Xcode/``devicectl`` without the device (#1994). Links remoted itself uses are the exception
    (see `remoted_handshake_uuid`).
    """
    return uuid.UUID(generate_host_id())


@functools.cache
def remoted_handshake_uuid() -> Optional[uuid.UUID]:
    """The UUID for an RSD handshake on a link the host ``remoted`` also uses; ``None`` off macOS.

    On such a link -- the USB NCM interface (``get_rsds``, tunneld) and remoted's own tunnel (the
    native tunnel) -- we connect from remoted's source address, so the device treats us as the same
    peer and remembers remoted's UUID for it. Any other identity makes iOS 27.2+ re-attach (see
    `default_handshake_uuid`) and reset what we just opened. The same address rule also means our
    connection replaces remoted's there, and remoted's redial replaces ours: nothing we send avoids
    that, which is why the NCM path suspends remoted and the native tunnel is opt-in. Pass
    the result as the handshake UUID there; ``None`` (off macOS, or when ``remotectl`` does not
    know) falls back to `default_handshake_uuid`.

    Resolved once per process: ``remotectl`` gets its answer from ``remoted``, which cannot give one
    while it is suspended -- so ``stop_remoted_if_required`` resolves it before suspending.
    """
    return host_remoted_uuid() if _IS_DARWIN else None


def host_remoted_uuid() -> Optional[uuid.UUID]:
    """The UUID the host's ``remoted`` identifies itself with in its RSD handshake; ``None`` if unknown.

    ``remotectl dumpstate`` reports it without root.
    """
    try:
        result = subprocess.run(
            [_REMOTECTL_PATH, "dumpstate"],
            capture_output=True,
            text=True,
            timeout=_REMOTECTL_TIMEOUT,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as e:
        logger.debug("remotectl unavailable: %r", e)
        return None
    return parse_remotectl_local_uuid(result.stdout)


def parse_remotectl_local_uuid(text: str) -> Optional[uuid.UUID]:
    """Extract the ``Local device`` UUID from ``remotectl dumpstate`` output; ``None`` if absent."""
    match = _REMOTECTL_LOCAL_UUID_RE.search(text)
    if match is None:
        logger.debug("remotectl dumpstate reported no local device UUID")
        return None
    return uuid.UUID(match.group("uuid"))


SHELL_USAGE = """
# This shell allows you to communicate directly with every RemoteXPC service.

# For example, you can do the following:
resp = await client.send_receive_request({"Command": "DoSomething"})
"""


class RemoteXPCConnection:
    def __init__(self, address: tuple[str, int], open_connection: Optional[Callable[..., Any]] = None):
        self._previous_frame_data = b""
        self.address = address
        # ``asyncio.open_connection``-compatible dialer. Defaults to the stdlib function; the
        # userspace tunnel injects one that relays device-bound connections through its in-process
        # stack, so no global ``asyncio.open_connection`` monkeypatch is needed.
        self._open_connection = open_connection or asyncio.open_connection
        self.next_message_id: dict[int, int] = {ROOT_CHANNEL: 0, REPLY_CHANNEL: 0}
        self.peer_info = None
        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None
        self._pending_window_updates: dict[int, int] = {}
        # Outbound (peer-granted) flow control, needed to push file transfers larger than the
        # peer's initial window. Both default to the HTTP/2 spec value until the peer's SETTINGS
        # and WINDOW_UPDATE frames say otherwise.
        self._peer_initial_window_size = DEFAULT_PEER_WINDOW_SIZE
        self._outbound_connection_window = DEFAULT_PEER_WINDOW_SIZE
        self._outbound_stream_windows: dict[int, int] = {}
        # Client-initiated streams must be odd; ROOT_CHANNEL and REPLY_CHANNEL take 1 and 3.
        self._next_outbound_stream_id = 5
        # Data frames read out of turn during a file transfer, replayed by receive_response().
        self._buffered_data_frames: deque[DataFrame] = deque()
        # Streams we finished pushing a file transfer on. The device resets them once it has the
        # payload, which is normal completion rather than an error.
        self._finished_file_transfer_streams: set[int] = set()
        self._file_chunk_queues: dict[int, asyncio.Queue[Union[bytes, BaseException]]] = {}
        self._file_chunk_reader_task: Optional[asyncio.Task[None]] = None
        # Serialise request/response round-trips. ``send_receive_request`` is a
        # write-then-read against a single shared reader + ``_previous_frame_data``
        # buffer with no per-request stream demux, so two concurrent callers
        # interleave their reads and steal each other's frames -- one observes
        # "0 bytes read" and the connection is corrupted for good. Any caller
        # that issues requests from multiple tasks (e.g. a periodic keepalive
        # alongside normal RPCs) needs this.
        self._request_lock = asyncio.Lock()

    async def __aenter__(self) -> "RemoteXPCConnection":
        await self.connect()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()

    async def connect(self) -> None:
        self._reader, self._writer = await self._open_connection(self.address[0], self.address[1])
        try:
            await self._do_handshake()
        except asyncio.TimeoutError as e:
            await self.close()
            raise RemoteXPCHandshakeTimeoutError(
                f"The service at {self.address[0]}:{self.address[1]} did not answer the RemoteXPC handshake."
            ) from e
        except Exception:
            await self.close()
            raise

    @property
    def reader(self) -> asyncio.StreamReader:
        """The stream reader.

        :raises NotConnectedError: if accessed before ``connect()`` (or after ``close()``).
        """
        if self._reader is None:
            raise NotConnectedError("RemoteXPCConnection is not open; call connect() first.")
        return self._reader

    @property
    def writer(self) -> asyncio.StreamWriter:
        """The stream writer.

        :raises NotConnectedError: if accessed before ``connect()`` (or after ``close()``).
        """
        if self._writer is None:
            raise NotConnectedError("RemoteXPCConnection is not open; call connect() first.")
        return self._writer

    @property
    def local_address(self) -> tuple[str, int]:
        """``(host, port)`` of the local end of the connection to the device.

        Useful when sending the device a callback endpoint that lives on this
        host's tunnel interface — e.g. an RTP receiver port in
        ``mediastreamstart``. Only valid while the connection is open.
        """
        sockname = self.writer.get_extra_info("sockname")
        if not isinstance(sockname, tuple):
            # e.g. an AF_UNIX sockname ('' or a path) — the userspace tunnel's relay dialer.
            # This connection has no kernel endpoint the device could ever reach, and the old
            # loopback-TCP relay's ('127.0.0.1', port) answer was equally unreachable — fail
            # loudly instead of advertising a dead endpoint.
            raise PyMobileDevice3Exception("The connection has no local address over the in-process userspace tunnel.")
        address = cast("tuple[str, int]", sockname)
        return address[0], address[1]

    async def close(self) -> None:
        self._pending_window_updates.clear()
        if self._file_chunk_reader_task is not None:
            self._file_chunk_reader_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._file_chunk_reader_task
            self._file_chunk_reader_task = None
        self._file_chunk_queues.clear()
        if self._writer is None:
            return
        self._writer.close()
        with contextlib.suppress(Exception):
            await self._writer.wait_closed()
        self._writer = None
        self._reader = None

    async def send_device_handshake(self, peer_uuid: Optional[uuid.UUID] = None) -> None:
        """Announce the client as a modern (non-legacy) RemoteXPC peer.

        Send only on the RSD/remoted control connection, after the HTTP/2
        handshake and before reading ``peer_info``.

        :param peer_uuid: UUID to identify this peer with; ``None`` sends `default_handshake_uuid`.
        """
        if peer_uuid is None:
            peer_uuid = await asyncio.to_thread(default_handshake_uuid)
        await self.send_request({
            "MessageType": "Handshake",
            "MessagingProtocolVersion": XpcUInt64Type(MESSAGING_PROTOCOL_VERSION),
            "UUID": peer_uuid,
            "Properties": {
                "RemoteXPCVersionFlags": XpcUInt64Type(REMOTE_XPC_VERSION_FLAGS),
                "SensitivePropertiesVisible": True,
            },
            "Services": {},
        })

    async def send_request(self, data: dict[str, Any], wanting_reply: bool = False) -> None:
        xpc_wrapper = create_xpc_wrapper(
            data, message_id=self.next_message_id[ROOT_CHANNEL], wanting_reply=wanting_reply
        )
        # A message larger than the peer's frame size (e.g. a restoreserviced preflight payload
        # carrying firmware) has to be split into window-sized DATA frames, otherwise the device
        # answers with GOAWAY "too large frame size". A small one is a single frame, but it is
        # charged against the window all the same.
        offset = 0
        while offset < len(xpc_wrapper):
            offset += await self._send_flow_controlled(ROOT_CHANNEL, xpc_wrapper, offset, len(xpc_wrapper))
        # RemoteXPC numbers each side's messages with its own parity, stepping by two: the
        # initiator's are odd, the listener's even. A listener asked to reply to an even id
        # aborts ("Attempted to send non-reply msg on the reply channel"), taking the daemon
        # down. Only the empty handshake message is 0.
        self.next_message_id[ROOT_CHANNEL] = (self.next_message_id[ROOT_CHANNEL] + 1) | 1

    async def iter_file_chunks(self, total_size: int, file_idx: int = 0) -> AsyncIterable[bytes]:
        stream_id = (file_idx + 1) * 2
        chunk_queue: asyncio.Queue[Union[bytes, BaseException]] = asyncio.Queue()
        self._file_chunk_queues[stream_id] = chunk_queue
        try:
            await self._open_channel(stream_id, XpcFlags.FILE_TX_STREAM_RESPONSE)
            if self._file_chunk_reader_task is None:
                self._file_chunk_reader_task = asyncio.create_task(self._route_file_chunks())

            size = 0
            while size < total_size:
                chunk = await chunk_queue.get()
                if isinstance(chunk, BaseException):
                    raise chunk
                size += len(chunk)
                yield chunk
        finally:
            self._file_chunk_queues.pop(stream_id, None)
            await self._replenish_receive_window(stream_id, force=True)
            if not self._file_chunk_queues and self._file_chunk_reader_task is not None:
                self._file_chunk_reader_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._file_chunk_reader_task
                self._file_chunk_reader_task = None

    async def _route_file_chunks(self) -> None:
        try:
            while self._file_chunk_queues:
                frame = await self._receive_next_data_frame()
                if "END_STREAM" in frame.flags:
                    continue

                chunk_queue = self._file_chunk_queues.get(frame.stream_id)
                if chunk_queue is not None:
                    chunk_queue.put_nowait(frame.data)
                    continue

                xpc_wrapper = XpcWrapper.parse(frame.data)
                if not xpc_wrapper.flags & XpcFlags.FILE_TX_STREAM_REQUEST:
                    raise ProtocolError(f"The device opened an unexpected file transfer stream: {frame.stream_id}")
        except asyncio.CancelledError:
            raise
        except BaseException as e:
            for chunk_queue in self._file_chunk_queues.values():
                chunk_queue.put_nowait(e)

    async def receive_file(self, total_size: int) -> bytes:
        buf = b""
        async for chunk in self.iter_file_chunks(total_size):
            buf += chunk
        return buf

    async def receive_response(self) -> dict[str, Any]:
        while True:
            frame = await self._receive_next_data_frame()
            try:
                payload = XpcWrapper.parse(self._previous_frame_data + frame.data).payload
                self._previous_frame_data = b""
            except TruncatedDataError:
                self._previous_frame_data += frame.data
                continue
            if payload is None:
                continue
            if payload.type != XpcMessageType.DICTIONARY:
                raise ProtocolError(f"The device sent an XPC reply that is not a dictionary: {payload.type!r}")
            if not payload.data:
                # an empty dictionary carries nothing to answer with
                continue
            return decode_xpc_object(payload)

    async def send_receive_request(self, data: dict[str, Any]) -> dict[str, Any]:
        async with self._request_lock:
            await self.send_request(data, wanting_reply=True)
            return await self.receive_response()

    def shell(self) -> None:
        start_ipython_shell(
            header=highlight(
                SHELL_USAGE, cast(Any, lexers).PythonLexer(), formatters.Terminal256Formatter(style="native")
            ),
            user_ns={
                "client": self,
                "XpcInt64Type": XpcInt64Type,
                "XpcUInt64Type": XpcUInt64Type,
            },
        )

    async def _do_handshake(self) -> None:
        writer = self.writer
        writer.write(HTTP2_MAGIC)
        await self._drain(writer)

        # send h2 headers
        await self._send_frame(
            SettingsFrame(
                settings={
                    SettingsFrame.MAX_CONCURRENT_STREAMS: DEFAULT_SETTINGS_MAX_CONCURRENT_STREAMS,
                    SettingsFrame.INITIAL_WINDOW_SIZE: DEFAULT_SETTINGS_INITIAL_WINDOW_SIZE,
                }
            )
        )
        await self._send_frame(WindowUpdateFrame(stream_id=0, window_increment=DEFAULT_WIN_SIZE_INCR))
        await self._send_frame(HeadersFrame(stream_id=ROOT_CHANNEL, flags=["END_HEADERS"]))

        # send first actual requests — frame order matches what devicectl emits:
        #   Headers#1, Data#1(init), Headers#3, Data#1(term=0x0201), Data#3(INIT_HANDSHAKE).
        # The receiving daemon validates frame ordering at the RemoteServiceDiscovery
        # layer and rejects with "Invalid or missing remote device connection version
        # flags" + xpc_connection_cancel() if Headers#3 isn't seen before Data#1's term.
        await self.send_request({})
        await self._send_frame(HeadersFrame(stream_id=REPLY_CHANNEL, flags=["END_HEADERS"]))
        await self._send_frame(DataFrame(stream_id=ROOT_CHANNEL, data=XpcWrapper(flags=0x0201).build()))
        await self._send_frame(
            DataFrame(
                stream_id=REPLY_CHANNEL,
                data=XpcWrapper(flags=XpcFlags.ALWAYS_SET | XpcFlags.INIT_HANDSHAKE).build(),
            )
        )
        self.next_message_id[REPLY_CHANNEL] += 1

        settings_frame = await asyncio.wait_for(self._receive_frame(), FIRST_REPLY_TIMEOUT)
        while not isinstance(settings_frame, SettingsFrame):
            # The peer grants its connection window before ACKing settings; record it rather than
            # discarding it, otherwise outbound file transfers stall at the 65535 default.
            if not self._apply_flow_control_frame(settings_frame):
                raise ProtocolError(
                    f"The device sent an unexpected frame during the RemoteXPC handshake: {settings_frame}"
                )
            settings_frame = await asyncio.wait_for(self._receive_frame(), FIRST_REPLY_TIMEOUT)
        self._apply_flow_control_frame(settings_frame)

        await self._send_frame(SettingsFrame(flags=["ACK"]))

    def _outbound_budget(self, stream_id: int) -> int:
        stream_window = self._outbound_stream_windows.get(stream_id, self._peer_initial_window_size)
        return max(0, min(self._outbound_connection_window, stream_window, MAX_OUTBOUND_FRAME_SIZE))

    def _consume_outbound(self, stream_id: int, amount: int) -> None:
        self._outbound_connection_window -= amount
        self._outbound_stream_windows[stream_id] = (
            self._outbound_stream_windows.get(stream_id, self._peer_initial_window_size) - amount
        )

    def _apply_flow_control_frame(self, frame: Frame) -> bool:
        """Consume a peer frame that only affects flow control. Returns True if it was handled."""
        if isinstance(frame, WindowUpdateFrame):
            if frame.stream_id == 0:
                self._outbound_connection_window += frame.window_increment
            else:
                current = self._outbound_stream_windows.get(frame.stream_id, self._peer_initial_window_size)
                self._outbound_stream_windows[frame.stream_id] = current + frame.window_increment
            return True
        if isinstance(frame, SettingsFrame) and "ACK" not in frame.flags:
            new_initial = frame.settings.get(SettingsFrame.INITIAL_WINDOW_SIZE)
            if new_initial is not None:
                # A new INITIAL_WINDOW_SIZE retroactively shifts every open stream's window.
                delta = new_initial - self._peer_initial_window_size
                self._peer_initial_window_size = new_initial
                for open_stream in self._outbound_stream_windows:
                    self._outbound_stream_windows[open_stream] += delta
            return True
        return False

    async def _send_flow_controlled(self, stream_id: int, data: bytes, offset: int, total: int) -> int:
        """Send one window-sized DATA chunk from *data* at *offset*, blocking until there is room.

        :returns: how many bytes were sent.
        """
        budget = self._outbound_budget(stream_id)
        while budget == 0:
            try:
                await asyncio.wait_for(self._pump_one_frame(), FILE_TRANSFER_WINDOW_TIMEOUT)
            except asyncio.TimeoutError as e:
                raise ProtocolError(
                    f"The device stopped accepting file data on stream {stream_id} after {offset}/{total} bytes "
                    "(flow-control timeout)."
                ) from e
            budget = self._outbound_budget(stream_id)
        chunk = data[offset : offset + budget]
        await self._send_frame(DataFrame(stream_id=stream_id, data=chunk))
        return len(chunk)

    async def send_file_transfer(self, transfer_id: int, data: bytes) -> None:
        """Push the payload of a previously announced `FileTransferType` to the device.

        The announcement (a `FileTransferType` in a request) only declares the size and a
        ``transfer_id``; the bytes travel on their own HTTP/2 stream. That stream must be
        client-initiated and therefore **odd** — the device answers HEADERS on an even stream with
        ``GOAWAY``/``invalid stream_id`` — and its opening frame must carry the ``transfer_id`` as
        the XPC ``message_id``, which is how the device correlates stream to announcement
        (``Found pending stream ID for <id>``). The device acknowledges with a
        ``FILE_TX_STREAM_RESPONSE`` preamble, but that arrives *after* the payload and is not a
        gate: holding the stream open waiting for it makes the device reset it (``RST_STREAM``
        error 5), so the bytes follow the preamble immediately.

        :param transfer_id: identifier used in the corresponding `FileTransferType`.
        :param data: payload bytes; must match the announced ``transfer_size``.
        """
        stream_id = self._next_outbound_stream_id
        self._next_outbound_stream_id += 2

        await self._send_frame(HeadersFrame(stream_id=stream_id, flags=["END_HEADERS"]))
        # The preamble is a DATA frame, so it is flow controlled too. Sending it unaccounted
        # overruns the connection window once a previous transfer has drained it, and the device
        # answers with GOAWAY error 3 (FLOW_CONTROL_ERROR).
        preamble = XpcWrapper(
            flags=XpcFlags.FILE_TX_STREAM_REQUEST | XpcFlags.ALWAYS_SET, message_id=transfer_id
        ).build()
        await self._send_flow_controlled(stream_id, preamble, 0, len(preamble))
        offset = 0
        while offset < len(data):
            offset += await self._send_flow_controlled(stream_id, data, offset, len(data))
        await self._send_frame(DataFrame(stream_id=stream_id, data=b"", flags=["END_STREAM"]))
        self._finished_file_transfer_streams.add(stream_id)

    async def _pump_one_frame(self) -> Frame:
        """Read one frame, applying flow control and buffering data frames meant for others."""
        while True:
            frame = await self._receive_frame()
            if isinstance(frame, GoAwayFrame):
                raise StreamClosedError(f"The device closed the connection: {frame}")
            if isinstance(frame, RstStreamFrame):
                if frame.stream_id in self._finished_file_transfer_streams:
                    continue
                raise StreamClosedError(f"The device reset the stream: {frame}")
            if self._apply_flow_control_frame(frame):
                return frame
            if isinstance(frame, DataFrame):
                return frame

    async def _open_channel(self, stream_id: int, flags: int) -> None:
        flags |= XpcFlags.ALWAYS_SET
        await self._send_frame(HeadersFrame(stream_id=stream_id, flags=["END_HEADERS"]))
        await self._send_frame(DataFrame(stream_id=stream_id, data=XpcWrapper(flags=flags).build()))

    async def _send_frame(self, frame: Frame) -> None:
        if isinstance(frame, DataFrame):
            # Every DATA frame spends the peer's window, the handshake's and the requests' included.
            # Leaving any of them uncounted lets a later file transfer overrun the connection window
            # by that much, which the device answers with GOAWAY error 3 (FLOW_CONTROL_ERROR)
            # whenever it has not granted more window by then.
            self._consume_outbound(frame.stream_id, len(frame.data))
        writer = self.writer
        writer.write(frame.serialize())
        await self._drain(writer)

    async def _receive_next_data_frame(self) -> DataFrame:
        while True:
            if self._buffered_data_frames:
                return self._buffered_data_frames.popleft()
            frame = await self._receive_frame()
            self._apply_flow_control_frame(frame)

            if isinstance(frame, GoAwayFrame):
                raise StreamClosedError(f"The device closed the connection: {frame}")
            if isinstance(frame, RstStreamFrame):
                if frame.stream_id in self._finished_file_transfer_streams:
                    continue
                raise StreamClosedError(f"The device reset the stream: {frame}")
            if not isinstance(frame, DataFrame):
                continue

            if frame.stream_id % 2 == 0 and frame.body_len > 0:
                await self._replenish_receive_window(frame.stream_id, frame.body_len)

            return frame

    async def _replenish_receive_window(self, stream_id: int, increment: int = 0, force: bool = False) -> None:
        pending_increment = self._pending_window_updates.get(stream_id, 0) + increment
        if not force and pending_increment < WINDOW_UPDATE_THRESHOLD:
            self._pending_window_updates[stream_id] = pending_increment
            return
        if pending_increment == 0:
            return

        self._pending_window_updates.pop(stream_id, None)
        writer = self.writer
        writer.write(WindowUpdateFrame(stream_id=0, window_increment=pending_increment).serialize())
        writer.write(WindowUpdateFrame(stream_id=stream_id, window_increment=pending_increment).serialize())
        await self._drain(writer)

    async def _drain(self, writer: asyncio.StreamWriter) -> None:
        """Flush what was written to the peer.

        :raises ConnectionTerminatedError: If the peer closed the connection or it failed.
        """
        try:
            await writer.drain()
        except OSError as e:
            raise ConnectionTerminatedError() from e

    async def _receive_frame(self) -> Frame:
        buf = await self._recvall(FRAME_HEADER_SIZE)
        frame, additional_size = Frame.parse_frame_header(memoryview(buf))
        frame.parse_body(memoryview(await self._recvall(additional_size)))
        return frame

    async def _recvall(self, size: int) -> bytes:
        reader = self.reader
        data = b""
        while len(data) < size:
            try:
                chunk = await reader.readexactly(size - len(data))
            except (IncompleteReadError, OSError) as e:
                raise ConnectionTerminatedError() from e
            data += chunk
        return data
