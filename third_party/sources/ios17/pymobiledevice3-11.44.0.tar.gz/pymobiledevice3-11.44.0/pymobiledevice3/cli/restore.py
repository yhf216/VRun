import asyncio
import contextlib
import logging
import plistlib
import tempfile
from collections.abc import Generator
from pathlib import Path
from typing import IO, Annotated, Any, Optional, Union, cast

import requests
import typer
from ipsw_parser.ipsw import IPSW
from pygments import formatters, highlight, lexers
from typer_injector import Depends, InjectingTyper

from pymobiledevice3 import usbmux
from pymobiledevice3.cli.cli_common import (
    RSDServiceProviderDep,
    async_command,
    cli_loop,
    is_invoked_for_completion,
    print_json,
    prompt_selection,
)
from pymobiledevice3.exceptions import (
    ConnectionFailedError,
    ConnectionFailedToUsbmuxdError,
    IncorrectModeError,
    MissingValueError,
    PyMobileDevice3Exception,
)
from pymobiledevice3.irecv import IRecv
from pymobiledevice3.lockdown import SERVICE_PORT as LOCKDOWN_PORT
from pymobiledevice3.lockdown import create_using_usbmux
from pymobiledevice3.restore.device import Device
from pymobiledevice3.restore.preflight import UPDATER_FIRMWARE_PREFIXES, collect_device_side_preflight
from pymobiledevice3.restore.recovery import Behavior, Recovery
from pymobiledevice3.restore.restore import Restore
from pymobiledevice3.service_connection import ServiceConnection
from pymobiledevice3.services.diagnostics import DiagnosticsService
from pymobiledevice3.utils import file_download, start_ipython_shell

logger = logging.getLogger(__name__)


SHELL_USAGE = """
# use `irecv` variable to access Restore mode API
# for example:
print(irecv.getenv('build-version'))
"""
IPSWME_API = "https://api.ipsw.me/v4/device/"


cli = InjectingTyper(
    name="restore",
    help="Restore/erase IPSWs, fetch blobs, and manage devices in Recovery/DFU.",
    no_args_is_help=True,
)

# How long the device prompt waits on each device for its description.
DEVICE_DESCRIPTION_TIMEOUT = 5.0
RESTORED_TYPE = "com.apple.mobile.restored"


async def _query_device_description(device: usbmux.MuxDevice) -> Optional[str]:
    service = await ServiceConnection.create_using_usbmux(device.serial, LOCKDOWN_PORT, connection_type="USB")
    try:
        query_type = await service.send_recv_plist({"Label": "pymobiledevice3", "Request": "QueryType"})
        if query_type.get("Type") == RESTORED_TYPE:
            return None
        values: list[Any] = []
        # lockdownd answers these before a session is started, so an unpaired device shows no Trust prompt.
        for key in ("DeviceName", "ProductType", "ProductVersion"):
            reply = await service.send_recv_plist({"Label": "pymobiledevice3", "Request": "GetValue", "Key": key})
            values.append(reply.get("Value"))
    finally:
        await service.close()
    name, product_type, product_version = values
    return f"{name} ({product_type}, iOS {product_version}) {device.serial}"


async def _describe_device(device: usbmux.MuxDevice) -> Optional[str]:
    """The device prompt's line for ``device``, or None while it is in restore mode (busy restoring).

    Asking lockdownd's port is the same QueryType Apple's own restore tools send to every device;
    on a device in restore mode, restored answers it.
    """
    try:
        return await asyncio.wait_for(_query_device_description(device), DEVICE_DESCRIPTION_TIMEOUT)
    except (OSError, asyncio.TimeoutError, PyMobileDevice3Exception):
        return device.serial


async def _device_dependency_async(
    ecid: Annotated[
        Optional[str],
        typer.Option(
            help="Target device ECID; defaults to the first connected USB device or waits for Recovery/DFU.",
        ),
    ] = None,
) -> Optional[Device]:
    if is_invoked_for_completion():
        # prevent lockdown connection establishment when in autocomplete mode
        return None

    # ECID comes in as a CLI string (decimal or 0x-hex) but is matched against the integer
    # UniqueChipID; parse it once so the comparisons below actually work.
    ecid_value = int(ecid, 0) if ecid is not None else None

    try:
        logger.debug("searching among connected devices via lockdownd")
        devices = [dev for dev in await usbmux.list_devices() if dev.connection_type == "USB"]
        if ecid_value is not None:
            # Leave devices whose UDID names another ECID alone: one may be in the middle of its own
            # restore, where even a probing connection reaches its restored.
            devices = [dev for dev in devices if dev.ecid is None or dev.ecid == ecid_value]
        elif len(devices) > 1:
            descriptions = await asyncio.gather(*(_describe_device(dev) for dev in devices))
            # A device in restore mode is in the middle of a restore: leave it out.
            candidates = [(dev, desc) for dev, desc in zip(devices, descriptions) if desc is not None]
            if len(candidates) > 1:
                selected = cast(
                    int,
                    prompt_selection(
                        [desc for _, desc in candidates],
                        "Choose device",
                        idx=True,
                        hint="Pass --ecid to choose a device non-interactively.",
                    ),
                )
                candidates = [candidates[selected]]
            devices = [dev for dev, _ in candidates]
        for device in devices:
            try:
                lockdown = await create_using_usbmux(serial=device.serial, connection_type="USB")
            except (ConnectionFailedError, IncorrectModeError):
                continue
            if (ecid_value is None) or (lockdown.ecid == ecid_value):
                logger.debug("found device")
                found = Device(lockdown=lockdown)
                # Over lockdown this is a GetValue round-trip; resolve it now so the "connected device"
                # log line can report it instead of "unknown".
                await found.get_is_image4_supported()
                return found
            else:
                continue
    except ConnectionFailedToUsbmuxdError:
        pass

    logger.debug("waiting for device to be available in Recovery mode")
    return Device(irecv=IRecv(ecid=ecid_value))


def device_dependency(
    ecid: Annotated[
        Optional[str],
        typer.Option(
            help="Target device ECID; defaults to the first connected USB device or waits for Recovery/DFU.",
        ),
    ] = None,
) -> Optional[Device]:
    return cli_loop.run_until_complete(_device_dependency_async(ecid))


DeviceDep = Annotated[
    Device,
    Depends(device_dependency),
]


@contextlib.contextmanager
def tempzip_download_ctx(url: str) -> Generator[IPSW, None, None]:
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpzip = Path(tmpdir) / url.split("/")[-1]
        file_download(url, tmpzip)
        with ipsw_ctx(tmpzip) as ipsw:
            yield ipsw


@contextlib.contextmanager
def ipsw_ctx(path: Union[str, Path]) -> Generator[IPSW, None, None]:
    yield IPSW.create_from_path(str(path))


def ipsw_ctx_dependency(
    device: DeviceDep,
    ipsw: Annotated[
        Optional[str],
        typer.Option(
            "--ipsw",
            "-i",
            help="Path or URL to an IPSW. If omitted, choose a signed build interactively.",
        ),
    ] = None,
) -> contextlib.AbstractContextManager[IPSW]:
    if ipsw and not ipsw.startswith(("http://", "https://")):
        return ipsw_ctx(ipsw)

    url = ipsw
    if url is None:
        url = query_ipswme(cli_loop.run_until_complete(device.get_product_type()))
    return tempzip_download_ctx(url)


IPSWCtxDep = Annotated[
    contextlib.AbstractContextManager[IPSW],
    Depends(ipsw_ctx_dependency),
]


def tss_dependency(
    tss: Annotated[
        Optional[Path],
        typer.Option(help="Path to SHSH blob plist to use for signing requests."),
    ] = None,
) -> None:
    if tss is None:
        return
    with tss.open("rb") as tss_file:
        return plistlib.load(tss_file)


TSSDep = Annotated[
    Optional[dict[str, Any]],
    Depends(tss_dependency),
]


BehaviorOption = Annotated[
    Behavior,
    typer.Option(help="Restore behavior to use when selecting the BuildIdentity."),
]


def query_ipswme(identifier: str) -> str:
    resp = requests.get(IPSWME_API + identifier, headers={"Accept": "application/json"}, timeout=30)
    firmwares = resp.json()["firmwares"]
    display_list = [f"{entry['version']}: {entry['buildid']}" for entry in firmwares if entry["signed"]]
    idx = prompt_selection(display_list, "Choose version", idx=True)
    return firmwares[idx]["url"]


async def restore_update_task(
    device: Device,
    ipsw: IPSW,
    tss: Optional[dict[str, Any]],
    erase: bool,
    ignore_fdr: bool,
    enable_tss_batch: bool = False,
) -> None:
    behavior = Behavior.Update
    if erase:
        behavior = Behavior.Erase

    await Restore(
        ipsw,
        device,
        tss=tss,
        behavior=behavior,
        ignore_fdr=ignore_fdr,
        enable_tss_batch=enable_tss_batch,
    ).update()


@cli.command("shell")
def restore_shell(device: DeviceDep) -> None:
    """create an IPython shell for interacting with iBoot"""
    start_ipython_shell(
        header=highlight(
            SHELL_USAGE, cast(Any, lexers).PythonLexer(), cast(Any, formatters).Terminal256Formatter(style="native")
        ),
        user_ns={
            "irecv": device.irecv,
        },
    )


@cli.command("enter")
@async_command
async def restore_enter(device: DeviceDep) -> None:
    """enter Recovery mode"""
    if await device.get_is_lockdown():
        assert device.lockdown is not None  # get_is_lockdown() guarantees it
        await device.lockdown.enter_recovery()


@cli.command("exit")
def restore_exit() -> None:
    """exit Recovery mode"""
    irecv = IRecv()
    irecv.set_autoboot(True)
    irecv.reboot()


@cli.command("restart")
@async_command
async def restore_restart(device: DeviceDep) -> None:
    """restarts device"""
    if await device.get_is_lockdown():
        assert device.lockdown is not None  # get_is_lockdown() guarantees it
        async with DiagnosticsService(device.lockdown) as diagnostics:
            await diagnostics.restart()
    else:
        assert device.irecv is not None  # a Device is constructed with either lockdown or irecv
        device.irecv.reboot()


async def restore_tss_task(
    device: Device,
    ipsw_ctx: contextlib.AbstractContextManager[IPSW],
    out: Optional[IO[bytes]],
    behavior: Behavior = Behavior.Update,
) -> None:
    with ipsw_ctx as ipsw:
        tss = await Recovery(ipsw, device, behavior=behavior).fetch_tss_record()
    if out:
        plistlib.dump(tss, out)
    print_json(tss)


@cli.command("tss")
@async_command
async def restore_tss(
    device: DeviceDep,
    ipsw_ctx: IPSWCtxDep,
    out: Optional[Path] = None,
    behavior: BehaviorOption = Behavior.Update,
) -> None:
    """query SHSH blobs"""
    with out.open("wb") if out else contextlib.nullcontext() as out_file:
        await restore_tss_task(device, ipsw_ctx, out_file, behavior=behavior)


@cli.command("preflight")
@async_command
async def restore_preflight(device: DeviceDep) -> None:
    """
    Show the preflight data lockdown reports before a restore: PreflightInfo (each peripheral
    updater's identity fields and current nonce), FirmwarePreflightInfo (baseband) and ApParameters
    (AP and SEP nonces). Requires normal mode.
    """
    if device.lockdown is None:
        raise typer.BadParameter("preflight data is only available from a device in normal mode")
    result: dict[str, Any] = {}
    for key in ("PreflightInfo", "FirmwarePreflightInfo", "ApParameters"):
        try:
            result[key] = await device.lockdown.get_value("", key)
        except MissingValueError:
            result[key] = None
    print_json(result)


@cli.command("preflight-requests")
@async_command
async def restore_preflight_requests(
    device: DeviceDep,
    ipsw_ctx: IPSWCtxDep,
    rsd: RSDServiceProviderDep,
    updater: Annotated[
        Optional[list[str]],
        typer.Option(
            help=f"Updater to query (repeatable); default: all of {', '.join(UPDATER_FIRMWARE_PREFIXES)} except Baseband.",
        ),
    ] = None,
) -> None:
    """
    Ask the device to build the TSS request of each peripheral updater for the given IPSW, the way
    restored does during a restore (restoreserviced getdevicesidepreflightinfo; needs a tunnel and
    uploads each updater's firmware to the device). Prints the requests, their ticket and manifest
    tags, and the updaters that failed.
    """
    with ipsw_ctx as ipsw:
        build_identity = cast(dict[str, Any], Recovery(ipsw, device).build_identity)
        print_json(await collect_device_side_preflight(rsd, ipsw, build_identity, updater))


@cli.command("ramdisk")
@async_command
async def restore_ramdisk(device: DeviceDep, ipsw_ctx: IPSWCtxDep) -> None:
    """
    Boot only the update ramdisk without performing a restore (IPSW path or URL accepted).
    """
    with ipsw_ctx as ipsw:
        await Recovery(ipsw, device).boot_ramdisk()


@cli.command("update")
@async_command
async def restore_update(
    device: DeviceDep,
    ipsw_ctx: IPSWCtxDep,
    tss: TSSDep,
    erase: Annotated[
        bool,
        typer.Option(help="Erase and restore (factory reset) instead of updating in place."),
    ] = False,
    ignore_fdr: Annotated[
        bool,
        typer.Option(help="Connect to the FDR service only (debug mode; no traffic proxying)."),
    ] = False,
    tss_batch: Annotated[
        bool,
        typer.Option(
            "--tss-batch",
            help=(
                "Opt-in: request the prefetchable peripheral tickets (SE/SE2, Rose, Savage, T200, "
                "Centauri, eUICC, Baseband) together with the AP ticket, in the same TSS request, and "
                "serve them during the restore whenever the device asks with the identical request "
                "(iOS 18+). Adds no request; chips whose nonce changed are signed live as usual."
            ),
        ),
    ] = False,
) -> None:
    """
    Update or restore the device using an IPSW (local path or URL).
    """
    with ipsw_ctx as ipsw:
        await restore_update_task(
            device,
            ipsw,
            tss,
            erase,
            ignore_fdr,
            enable_tss_batch=tss_batch,
        )
