import json
import re
from datetime import datetime
from io import StringIO
from typing import cast
from uuid import UUID

import pytest

from pymobiledevice3.cli import syslog as syslog_module
from pymobiledevice3.lockdown_service_provider import LockdownServiceProvider
from pymobiledevice3.services.os_trace import (
    OS_TRACE_RELAY_STREAM_FLAGS_DEFAULT,
    OsActivityStreamFlag,
    SyslogEntry,
    SyslogLabel,
    SyslogLogLevel,
)

pytestmark = [pytest.mark.cli]

_FAKE_SERVICE_PROVIDER = cast(LockdownServiceProvider, object())


class _FakeOsTraceService:
    last_pid = None
    last_stream_flags = None

    def __init__(self, entries):
        self._entries = entries

    async def syslog(self, pid=-1, stream_flags=OS_TRACE_RELAY_STREAM_FLAGS_DEFAULT, **_kwargs):
        type(self).last_pid = pid
        type(self).last_stream_flags = stream_flags
        for entry in self._entries:
            yield entry


def _create_syslog_entry(message: str) -> SyslogEntry:
    return SyslogEntry(
        pid=123,
        timestamp=datetime(2024, 1, 1, 0, 0, 0),
        level=SyslogLogLevel.INFO,
        image_name="/usr/libexec/test-process",
        image_offset=0,
        filename="/usr/libexec/test-process",
        message=message,
    )


def _create_syslog_entry_with_level(message: str, level: SyslogLogLevel) -> SyslogEntry:
    entry = _create_syslog_entry(message)
    entry.level = level
    return entry


def _create_syslog_entries(messages: list[str]) -> list[SyslogEntry]:
    return [_create_syslog_entry(message) for message in messages]


async def _run_syslog_live(
    monkeypatch, capsys, entries: list[SyslogEntry], color: bool = False, **syslog_live_kwargs
) -> tuple[list[str], str]:
    monkeypatch.setattr(syslog_module, "OsTraceService", lambda lockdown: _FakeOsTraceService(entries))
    monkeypatch.setattr(syslog_module, "user_requested_colored_output", lambda: color)

    out = syslog_live_kwargs.pop("out", None)
    kwargs = {
        "pid": -1,
        "process_name": None,
        "match": [],
        "invert_match": [],
        "match_insensitive": [],
        "invert_match_insensitive": [],
        "include_label": False,
        "regex": [],
        "insensitive_regex": [],
        "subsystem": [],
        "category": [],
        "no_debug": False,
        "no_info": False,
    }
    kwargs.update(syslog_live_kwargs)

    await syslog_module.syslog_live(
        service_provider=_FAKE_SERVICE_PROVIDER,
        out=out,
        **kwargs,
    )

    printed_lines = capsys.readouterr().out.strip().splitlines()
    return printed_lines, "" if out is None else out.getvalue()


@pytest.mark.parametrize(
    ("invert_match", "invert_match_insensitive", "expected"),
    [
        ([], [], False),
        (["match"], [], True),
        (["MobileSafari"], [], True),
        (["dont"], [], False),
        ([], ["MaTCh"], True),
        ([], ["mobilesafari"], True),
        ([], ["missing"], False),
        (["match"], ["missing"], True),
        (["dont"], ["MaTCh"], True),
        (["dont"], ["missing"], False),
        (["match", "dont"], [], True),
        ([], ["missing", "MaTCh"], True),
        (["dont", "missing"], ["absent"], False),
    ],
)
def test_should_skip_line(invert_match: list[str], invert_match_insensitive: list[str], expected: bool) -> None:
    assert (
        syslog_module._should_skip_line(
            "MobileSafari match",
            invert_match,
            invert_match_insensitive,
        )
        == expected
    )


@pytest.mark.parametrize(
    ("match", "match_insensitive", "match_regex", "expected"),
    [
        ([], [], [], True),
        (["match"], [], [], True),
        (["MobileSafari"], [], [], True),
        (["missing"], [], [], False),
        (["MobileSafari", "match"], [], [], True),
        (["MobileSafari", "missing"], [], [], False),
        ([], ["mobilesafari"], [], True),
        ([], ["match"], [], True),
        ([], ["missing"], [], False),
        ([], ["mobilesafari", "match"], [], True),
        ([], ["mobilesafari", "missing"], [], False),
        (["match"], ["mobilesafari"], [], True),
        (["MobileSafari"], ["match"], [], True),
        (["match"], ["missing"], [], False),
        (["missing"], ["mobilesafari"], [], False),
        (["MobileSafari", "match"], ["mobilesafari", "match"], [], True),
        (["MobileSafari", "match"], ["mobilesafari", "missing"], [], False),
        ([], [], [syslog_module.re.compile(r".*(match).*")], True),
        ([], [], [syslog_module.re.compile(r".*(missing).*")], False),
        ([], [], [syslog_module.re.compile(r".*(match).*"), syslog_module.re.compile(r".*(missing).*")], True),
        (["match"], [], [syslog_module.re.compile(r".*(MobileSafari).*")], True),
        (["match"], [], [syslog_module.re.compile(r".*(missing).*")], False),
        ([], ["mobilesafari"], [syslog_module.re.compile(r".*(match).*")], True),
        ([], ["mobilesafari"], [syslog_module.re.compile(r".*(missing).*")], False),
    ],
)
def test_should_keep_line(
    match: list[str], match_insensitive: list[str], match_regex: list[re.Pattern[str]], expected: bool
) -> None:
    assert (
        syslog_module._should_keep_line(
            "MobileSafari match",
            match,
            match_insensitive,
            match_regex,
        )
        == expected
    )


@pytest.mark.asyncio
async def test_syslog_live_invert_match(monkeypatch, capsys):
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["keep this line", "skip this line"]),
        invert_match=["skip"],
    )
    assert len(printed_lines) == 1
    assert printed_lines[0].endswith("keep this line")


@pytest.mark.asyncio
async def test_syslog_live_match(monkeypatch, capsys):
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["daemon ready", "daemon error", "worker ready"]),
        match=["daemon"],
        invert_match=["error"],
    )
    assert len(printed_lines) == 1
    assert printed_lines[0].endswith("daemon ready")


@pytest.mark.asyncio
async def test_syslog_live_invert_match_uses_disjunction_for_repeated_values(monkeypatch, capsys):
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["daemon ready", "daemon ready error", "worker error"]),
        invert_match=["daemon", "error"],
    )
    assert len(printed_lines) == 0


@pytest.mark.asyncio
async def test_syslog_live_match_insensitive(monkeypatch, capsys):
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["MobileSafari ready", "backboardd ready", "Worker READY"]),
        match_insensitive=["mobilesafari"],
        invert_match_insensitive=["ready"],
    )
    assert len(printed_lines) == 0


@pytest.mark.asyncio
async def test_syslog_live_process_name_and_start_after_filter_output(monkeypatch, capsys):
    entries = [
        _create_syslog_entry("warmup"),
        SyslogEntry(
            pid=123,
            timestamp=datetime(2024, 1, 1, 0, 0, 1),
            level=SyslogLogLevel.INFO,
            image_name="/usr/libexec/other-process",
            image_offset=0,
            filename="/usr/libexec/other-process",
            message="START now",
        ),
        _create_syslog_entry("before START"),
        _create_syslog_entry("START now"),
        _create_syslog_entry("after start"),
    ]

    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        entries,
        process_name="test-process",
        start_after="START",
    )
    assert len(printed_lines) == 4
    assert printed_lines[0] == 'Waiting for "START" ...'
    assert printed_lines[1].endswith("before START")
    assert printed_lines[2].endswith("START now")
    assert printed_lines[3].endswith("after start")


@pytest.mark.asyncio
async def test_syslog_live_regex_filters_and_writes_plain_output_to_out(monkeypatch, capsys):
    entries = [
        _create_syslog_entry("daemon ready"),
        _create_syslog_entry("worker ready"),
        _create_syslog_entry("springboard ready"),
    ]
    out = StringIO()

    printed_lines, out_value = await _run_syslog_live(
        monkeypatch,
        capsys,
        entries,
        out=out,
        regex=["daemon", "worker"],
    )
    out_lines = out_value.strip().splitlines()
    assert len(printed_lines) == 2
    assert len(out_lines) == 2
    assert printed_lines[0].endswith("daemon ready")
    assert printed_lines[1].endswith("worker ready")
    assert out_lines == printed_lines


@pytest.mark.asyncio
async def test_syslog_live_no_debug_suppresses_only_debug(monkeypatch, capsys):
    entries = [
        _create_syslog_entry_with_level("info line", SyslogLogLevel.INFO),
        _create_syslog_entry_with_level("debug line", SyslogLogLevel.DEBUG),
        _create_syslog_entry_with_level("notice line", SyslogLogLevel.NOTICE),
        _create_syslog_entry_with_level("error line", SyslogLogLevel.ERROR),
    ]

    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        entries,
        no_debug=True,
    )

    assert len(printed_lines) == 3
    assert printed_lines[0].endswith("info line")
    assert printed_lines[1].endswith("notice line")
    assert printed_lines[2].endswith("error line")
    assert _FakeOsTraceService.last_stream_flags == (OS_TRACE_RELAY_STREAM_FLAGS_DEFAULT & ~OsActivityStreamFlag.DEBUG)


@pytest.mark.asyncio
async def test_syslog_live_no_info_suppresses_only_info(monkeypatch, capsys):
    entries = [
        _create_syslog_entry_with_level("info line", SyslogLogLevel.INFO),
        _create_syslog_entry_with_level("debug line", SyslogLogLevel.DEBUG),
        _create_syslog_entry_with_level("notice line", SyslogLogLevel.NOTICE),
    ]

    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        entries,
        no_info=True,
    )

    assert len(printed_lines) == 2
    assert printed_lines[0].endswith("debug line")
    assert printed_lines[1].endswith("notice line")
    assert _FakeOsTraceService.last_stream_flags == (OS_TRACE_RELAY_STREAM_FLAGS_DEFAULT & ~OsActivityStreamFlag.INFO)


@pytest.mark.parametrize("color", [False, True])
def test_format_line_label_with_braces(color: bool) -> None:
    # https://github.com/doronz88/pymobiledevice3/issues/1826 - a subsystem/category
    # containing str.format() metacharacters (e.g. "{34}") must be emitted verbatim
    # instead of being parsed as a replacement field.
    entry = _create_syslog_entry("hello")
    entry.label = SyslogLabel(subsystem="com.foo.{34}", category="{bad} {")
    line = syslog_module.format_line(entry, include_label=True, image_offset=False, color=color)
    assert "[com.foo.{34}][{bad} {]" in line


_ANSI_SGR = re.compile(r"\x1b\[[0-9;]*m")
_HIGHLIGHTED = re.compile(r"\x1b\[1m\x1b\[4m([^\x1b]*)\x1b\[0m")


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "filters",
    [
        {"match": ["1"]},
        {"match": ["["]},
        {"match_insensitive": ["<error>"]},
        {"match_insensitive": ["FAILED"]},
        {"regex": [r"\d+"]},
        {"insensitive_regex": [r"BUNDLE \d"]},
        {"match": ["load"], "match_insensitive": ["TEST-process"], "regex": [r"\d+"]},
    ],
)
async def test_syslog_live_highlight_only_adds_escape_codes(monkeypatch, capsys, filters):
    # Highlighting must leave the text alone: with the escape codes stripped, the colored
    # line is the plain line, whatever the match filters hit (digits and "[" also appear
    # inside the escape codes themselves).
    entry = _create_syslog_entry_with_level("failed to load bundle 1, retry 1", SyslogLogLevel.ERROR)
    entry.image_offset = 0x1F
    entry.label = SyslogLabel(subsystem="com.apple.foo", category="net")
    options = {"include_label": True, "image_offset": True, **filters}

    plain_lines, _ = await _run_syslog_live(monkeypatch, capsys, [entry], **options)
    styled_lines, _ = await _run_syslog_live(monkeypatch, capsys, [entry], color=True, **options)

    assert len(plain_lines) == 1
    assert [_ANSI_SGR.sub("", line) for line in styled_lines] == plain_lines
    assert _HIGHLIGHTED.findall(styled_lines[0])


@pytest.mark.asyncio
async def test_syslog_live_match_insensitive_highlight_across_fields(monkeypatch, capsys):
    # "<error>" spans the plain "<" and the colored level, so it is not a substring of the
    # colored line. Highlighting it used to raise ValueError and end the stream.
    styled_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        [_create_syslog_entry_with_level("failed", SyslogLogLevel.ERROR)],
        color=True,
        match_insensitive=["<error>"],
    )
    assert len(styled_lines) == 1
    assert "".join(_HIGHLIGHTED.findall(styled_lines[0])) == "<ERROR>"


@pytest.mark.asyncio
async def test_syslog_live_match_insensitive_highlights_every_hit(monkeypatch, capsys):
    styled_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["Ready, still READY"]),
        color=True,
        match_insensitive=["ready"],
    )
    assert _HIGHLIGHTED.findall(styled_lines[0]) == ["Ready", "READY"]


@pytest.mark.asyncio
async def test_syslog_live_regex_highlights_every_match(monkeypatch, capsys):
    styled_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["retry 10 of 12"]),
        color=True,
        regex=[r"\d+"],
    )
    assert _HIGHLIGHTED.findall(styled_lines[0]) == ["2024", "01", "01", "00", "00", "00", "123", "10", "12"]


def test_format_json_line_with_label():
    entry = SyslogEntry(
        pid=42,
        timestamp=datetime(2026, 4, 18, 10, 15, 32, 123456),
        level=SyslogLogLevel.ERROR,
        image_name="/p/App",
        image_offset=16,
        filename="/p/App",
        message="hello",
        label=SyslogLabel(subsystem="com.foo.bar", category="cat"),
        procid=42,
        thread_id=4321,
        image_uuid=UUID("016e54e1-6f01-3644-941d-5073a6134a7b"),
        process_image_uuid=UUID("7870bc32-030d-3497-80eb-d80b2de7dfaf"),
        mach_timestamp=135126255336423432,
    )
    obj = json.loads(syslog_module.format_json_line(entry))
    assert obj == {
        "pid": 42,
        "procid": 42,
        "thread_id": 4321,
        "timestamp": "2026-04-18T10:15:32.123456",
        "level": "ERROR",
        "image_name": "/p/App",
        "image_offset": 16,
        "image_uuid": "016e54e1-6f01-3644-941d-5073a6134a7b",
        "process_image_uuid": "7870bc32-030d-3497-80eb-d80b2de7dfaf",
        "filename": "/p/App",
        "mach_timestamp": 135126255336423432,
        "message": "hello",
        "label": {"subsystem": "com.foo.bar", "category": "cat"},
    }


def test_format_json_line_handles_null_label():
    entry = _create_syslog_entry("plain")  # no label
    obj = json.loads(syslog_module.format_json_line(entry))
    assert obj["label"] is None
    assert obj["message"] == "plain"


def test_format_json_line_preserves_unicode():
    entry = _create_syslog_entry("hello 🚀 мир")
    raw = syslog_module.format_json_line(entry)
    assert "🚀" in raw  # ensure_ascii=False keeps raw unicode
    assert json.loads(raw)["message"] == "hello 🚀 мир"


@pytest.mark.asyncio
async def test_syslog_live_json_emits_valid_ndjson(monkeypatch, capsys):
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["hello", "world"]),
        output_format=syslog_module.SyslogFormat.JSON,
    )
    assert len(printed_lines) == 2
    parsed = [json.loads(line) for line in printed_lines]
    assert [p["message"] for p in parsed] == ["hello", "world"]
    assert all(p["level"] == "INFO" for p in parsed)
    assert all(p["pid"] == 123 for p in parsed)


@pytest.mark.asyncio
async def test_syslog_live_json_applies_text_filters(monkeypatch, capsys):
    # The line filters select the same entries in JSON mode as in text mode.
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["keep this", "skip this", "keep but drop"]),
        output_format=syslog_module.SyslogFormat.JSON,
        match=["keep"],
        invert_match=["drop"],
        match_insensitive=["KEEP"],
        invert_match_insensitive=["SKIP"],
        regex=["keep"],
        insensitive_regex=["THIS"],
    )
    assert [json.loads(line)["message"] for line in printed_lines] == ["keep this"]


@pytest.mark.asyncio
async def test_syslog_live_json_applies_start_after(monkeypatch, capsys):
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["before", "MARKER hit", "after"]),
        output_format=syslog_module.SyslogFormat.JSON,
        start_after="MARKER",
    )
    assert [json.loads(line)["message"] for line in printed_lines] == ["MARKER hit", "after"]


@pytest.mark.asyncio
async def test_syslog_live_json_filters_see_rendered_line_not_only_message(monkeypatch, capsys):
    # Filters run against the same rendered text line as text mode, so metadata
    # (process name, level, ...) is matchable even when absent from the message.
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["plain message"]),
        output_format=syslog_module.SyslogFormat.JSON,
        match=["test-process"],
    )
    assert [json.loads(line)["message"] for line in printed_lines] == ["plain message"]


@pytest.mark.asyncio
async def test_syslog_live_json_applies_process_name_filter(monkeypatch, capsys):
    entries = [
        _create_syslog_entry("from test-process"),
        SyslogEntry(
            pid=456,
            timestamp=datetime(2024, 1, 1, 0, 0, 1),
            level=SyslogLogLevel.INFO,
            image_name="/usr/libexec/other",
            image_offset=0,
            filename="/usr/libexec/other",
            message="from other",
        ),
    ]
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        entries,
        output_format=syslog_module.SyslogFormat.JSON,
        process_name="test-process",
    )
    assert len(printed_lines) == 1
    assert json.loads(printed_lines[0])["message"] == "from test-process"


@pytest.mark.asyncio
async def test_syslog_live_json_applies_pid_filter(monkeypatch, capsys):
    entries = [
        _create_syslog_entry("pid 123"),  # default pid is 123
        SyslogEntry(
            pid=999,
            timestamp=datetime(2024, 1, 1, 0, 0, 1),
            level=SyslogLogLevel.INFO,
            image_name="/usr/libexec/test-process",
            image_offset=0,
            filename="/usr/libexec/test-process",
            message="pid 999",
        ),
    ]
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        entries,
        output_format=syslog_module.SyslogFormat.JSON,
        pid=999,
    )
    assert len(printed_lines) == 1
    assert json.loads(printed_lines[0])["pid"] == 999


@pytest.mark.asyncio
async def test_syslog_live_json_tees_to_out(monkeypatch, capsys):
    out = StringIO()
    printed_lines, out_value = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["one", "two"]),
        output_format=syslog_module.SyslogFormat.JSON,
        out=out,
    )
    out_lines = out_value.strip().splitlines()
    assert out_lines == printed_lines  # same NDJSON to both stdout and file
    assert [json.loads(line)["message"] for line in out_lines] == ["one", "two"]


@pytest.mark.asyncio
async def test_syslog_live_json_suppresses_start_after_banner(monkeypatch, capsys):
    # In text mode, `--start-after` prints a "Waiting for..." banner to stdout.
    # That would corrupt NDJSON; JSON mode must suppress it.
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        _create_syslog_entries(["one"]),
        output_format=syslog_module.SyslogFormat.JSON,
        start_after="one",
    )
    assert len(printed_lines) == 1
    # The single line must parse as valid JSON — no banner contamination.
    assert json.loads(printed_lines[0])["message"] == "one"


def _labeled_entry(message: str, subsystem: str, category: str) -> SyslogEntry:
    entry = _create_syslog_entry(message)
    entry.label = SyslogLabel(subsystem=subsystem, category=category)
    return entry


@pytest.mark.parametrize(
    ("subsystem", "category", "label", "expected"),
    [
        # no filters -> keep everything, labeled or not
        ([], [], None, True),
        ([], [], SyslogLabel(subsystem="com.apple.WebKit", category="session"), True),
        # a filter is active but the entry has no label -> drop
        (["com.apple.WebKit"], [], None, False),
        ([], ["session"], None, False),
        # exact subsystem
        (
            ["com.apple.WebKit.Network"],
            [],
            SyslogLabel(subsystem="com.apple.WebKit.Network", category="net"),
            True,
        ),
        (["com.apple.CoreFoundation"], [], SyslogLabel(subsystem="com.apple.WebKit.Network", category="net"), False),
        # glob subsystem (matches every WebKit sub-subsystem)
        (
            ["com.apple.WebKit*"],
            [],
            SyslogLabel(subsystem="com.apple.WebKit.Process", category="cache"),
            True,
        ),
        (["com.apple.WebKit*"], [], SyslogLabel(subsystem="com.apple.CoreFoundation", category="io"), False),
        # case-insensitive
        (["COM.APPLE.corefoundation"], [], SyslogLabel(subsystem="com.apple.CoreFoundation", category="io"), True),
        # disjunction within subsystem list
        (
            ["com.apple.CoreFoundation", "com.apple.WebKit*"],
            [],
            SyslogLabel(subsystem="com.apple.WebKit.Network", category="net"),
            True,
        ),
        # category glob
        ([], ["net"], SyslogLabel(subsystem="com.apple.WebKit.Network", category="net"), True),
        ([], ["cach*"], SyslogLabel(subsystem="com.apple.WebKit.Process", category="cache"), True),
        ([], ["io"], SyslogLabel(subsystem="com.apple.WebKit.Network", category="net"), False),
        # conjunction across subsystem AND category
        (
            ["com.apple.WebKit*"],
            ["net"],
            SyslogLabel(subsystem="com.apple.WebKit.Network", category="net"),
            True,
        ),
        (
            ["com.apple.WebKit*"],
            ["io"],
            SyslogLabel(subsystem="com.apple.WebKit.Network", category="net"),
            False,
        ),
    ],
)
def test_should_keep_label(subsystem, category, label, expected):
    assert syslog_module._should_keep_label(label, subsystem, category) == expected


@pytest.mark.asyncio
async def test_syslog_live_subsystem_filter(monkeypatch, capsys):
    entries = [
        _labeled_entry("network event", "com.apple.WebKit.Network", "net"),
        _labeled_entry("cf thing", "com.apple.CoreFoundation", "Loading"),
        _create_syslog_entry("no label here"),
    ]
    printed_lines, _ = await _run_syslog_live(monkeypatch, capsys, entries, subsystem=["com.apple.WebKit*"])
    assert len(printed_lines) == 1
    assert printed_lines[0].endswith("network event")


@pytest.mark.asyncio
async def test_syslog_live_category_filter(monkeypatch, capsys):
    entries = [
        _labeled_entry("cached", "com.apple.WebKit.Process", "cache"),
        _labeled_entry("networked", "com.apple.WebKit.Network", "net"),
    ]
    printed_lines, _ = await _run_syslog_live(monkeypatch, capsys, entries, category=["cache"])
    assert len(printed_lines) == 1
    assert printed_lines[0].endswith("cached")


@pytest.mark.asyncio
async def test_syslog_live_subsystem_and_category_conjunction(monkeypatch, capsys):
    entries = [
        _labeled_entry("net on webkit", "com.apple.WebKit.Network", "net"),
        _labeled_entry("net on other", "com.apple.CoreFoundation", "net"),
        _labeled_entry("io on webkit", "com.apple.WebKit.Network", "io"),
    ]
    printed_lines, _ = await _run_syslog_live(
        monkeypatch, capsys, entries, subsystem=["com.apple.WebKit*"], category=["net"]
    )
    assert len(printed_lines) == 1
    assert printed_lines[0].endswith("net on webkit")


@pytest.mark.asyncio
async def test_syslog_live_subsystem_filter_json(monkeypatch, capsys):
    entries = [
        _labeled_entry("keep", "com.apple.WebKit.Network", "net"),
        _labeled_entry("drop", "com.apple.CoreFoundation", "Loading"),
    ]
    printed_lines, _ = await _run_syslog_live(
        monkeypatch,
        capsys,
        entries,
        subsystem=["com.apple.WebKit*"],
        output_format=syslog_module.SyslogFormat.JSON,
    )
    assert len(printed_lines) == 1
    obj = json.loads(printed_lines[0])
    assert obj["message"] == "keep"
    assert obj["label"]["subsystem"] == "com.apple.WebKit.Network"


def test_cli_syslog_live_out_file_is_utf8_regardless_of_locale(monkeypatch, tmp_path):
    # The --out file must not depend on the host locale encoding (cp1252 on Windows before
    # Python 3.15), otherwise the same line that crashed stdout in issue #1942 also crashes
    # the file write.
    out_path = tmp_path / "syslog.log"
    seen_encoding: list[str] = []

    async def fake_syslog_live(service_provider, out, *args, **kwargs):
        seen_encoding.append(out.encoding)
        print("syslog \U0001f600 line", file=out)

    monkeypatch.setattr(syslog_module, "syslog_live", fake_syslog_live)

    syslog_module.cli_syslog_live(service_provider=_FAKE_SERVICE_PROVIDER, out=out_path)

    assert [encoding.lower().replace("-", "") for encoding in seen_encoding] == ["utf8"]
    # Windows text streams write \r\n; the line ending is not what this test is about.
    assert out_path.read_bytes().replace(b"\r\n", b"\n") == "syslog \U0001f600 line\n".encode()
